package com.example.shapedrawer;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button triangleButton = findViewById(R.id.TriangleButton);
        Button rectangleButton = findViewById(R.id.RectangleButton);
        Button circleButton = findViewById(R.id.CircleButton);
        Button redButton = findViewById(R.id.RedButton);
        Button greenButton = findViewById(R.id.GreenButton);
        Button blueButton = findViewById(R.id.BlueButton);
        ImageView drawable = findViewById(R.id.DrawButton);

        int resIDTriangle = getResources().getIdentifier("triangle" , "drawable", getPackageName());
        int resIDRect = getResources().getIdentifier("rect" , "drawable", getPackageName());
        int resIDCircle = getResources().getIdentifier("circle" , "drawable", getPackageName());

        triangleButton.setOnClickListener(t -> drawable.setBackgroundResource(resIDTriangle));
        rectangleButton.setOnClickListener(r -> drawable.setBackgroundResource(resIDRect));
        circleButton.setOnClickListener(c -> drawable.setBackgroundResource(resIDCircle));
        redButton.setOnClickListener(red -> drawable.getBackground().setTint(Color.RED));
        greenButton.setOnClickListener(g -> drawable.getBackground().setTint(Color.GREEN));
        blueButton.setOnClickListener(red -> drawable.getBackground().setTint(Color.BLUE));

    }

}